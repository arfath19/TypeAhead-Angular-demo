import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable , Observer } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'TypeAhead';

  search:any[]=[];
  posts:any[]=[];
   finArray:any[]=[] ;
   display:any[]=[];
   newArr:any[]=[];
  //  array: any[]=[];
  constructor(private http : HttpClient){
  }
  arr_val;
  displayVal(event){
    this.arr_val=event.substr(1,event.length-2); //to remove extra spaces
    this.newArr=[]
  }


  ngOnInit(){
    let url = 'http://localhost:9200';
    this.http.get(`${url}`).subscribe(users => {
        this.search.push(users);
    });
    // console.log(this.search)
    this.getPosts()
  }
  getPosts(){
    let url = 'http://localhost:9200';
    this.http.get(`${url}`).subscribe(() => {
    this.finArray=(this.search[0][0]);
    // console.log(this.finArray)
     
  });
  }
  search_value ='';
  onKey(event){
    this.search_value=event.target.value;

    this.display.push(this.findMatch(this.search_value));
    console.log(this.display);
    this.newArr=this.display[0];
    this.display=[];
    console.log(" new arr: ",this.newArr);


  }

  findMatch(wordTomatch){
    return this.finArray.filter(string_item=>{
      const regex=new RegExp(wordTomatch,'gi');
      return string_item.match(regex);
    })
  }

}
