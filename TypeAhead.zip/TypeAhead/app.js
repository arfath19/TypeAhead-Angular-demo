const express =require('express');

const app=express();


app.use((req,res,next)=>{
    res.setHeader('Access-Control-Allow-Origin',"*");
    res.setHeader('Access-Control-Allow-Headers',"Origin,X-Requested-With,Content-Type,Accept");
    res.setHeader('Access-Control-Allow-Methods',"GET,POST,PATCH,DELETE,OPTIONS");
    
    
    next();

})
 
app.get('/',(req,res,next)=>{
    const data = ['Beck Glenn', 'Becker Carl', 'Beckett Samuel', 'Beddoes Mick', 'Beecher Henry', 'Beethoven Ludwig', 'Begin Menachem', 'Belloc Hilaire', 'Bellow Saul', 'Augustine', 'Black Elk', 'Blair Robert', 'Blair Tony', 'Blake William'];
    res.status(200).send(([
        data
    ]));
    
});



module.exports=app;